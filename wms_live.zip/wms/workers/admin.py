from django.contrib import admin
from .models import Worker, Attendance

admin.site.register(Worker)
admin.site.register(Attendance)
